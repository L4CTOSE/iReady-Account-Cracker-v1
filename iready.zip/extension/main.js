javascript:(function() {
  var buttons = document.querySelectorAll('[id^="ca-keypad-button-"]');
  var closeButton = document.getElementById("modal_dialog_button");
  var stopFlag = false;

  var buttonInterval, closeButtonInterval;

  function clickRandomButton() {
    var randomIndex = Math.floor(Math.random() * buttons.length);
    buttons[randomIndex].click();
  }

  function stopAutomation() {
    clearInterval(buttonInterval);
    clearInterval(closeButtonInterval);
    document.removeEventListener("keydown", handleKeyDown);
    stopFlag = true;
  }

  function handleKeyDown(event) {
    if (event.key === "z") {
      stopAutomation();
    }
  }

  function executeBookmarklet() {
    buttonInterval = setInterval(clickRandomButton, 2.5);
    closeButtonInterval = setInterval(function() {
      closeButton.click();
    }, 1);

    var detectionElement = document.getElementById("k1-form-header-class-code");
    var observer = new MutationObserver(function(mutations) {
      mutations.forEach(function(mutation) {
        if (mutation.type === "childList" && mutation.target === detectionElement) {
          var classCode = detectionElement.textContent.trim();
          if (classCode === "CsLASS 915902") {
            stopAutomation();
          }
        }
      });
    });

    observer.observe(detectionElement, { childList: true });

    setTimeout(function() {
      stopAutomation();
      observer.disconnect();
    }, inf);

    document.addEventListener("keydown", handleKeyDown, false);
  }

  var startButton = document.createElement('button');
  startButton.textContent = 'Start';
  startButton.style.marginRight = '10px';
  startButton.addEventListener('click', executeBookmarklet);

  var stopButton = document.createElement('button');
  stopButton.textContent = 'Stop';
  stopButton.addEventListener('click', stopAutomation);

  var menu = document.createElement('div');
  menu.style.position = 'fixed';
  menu.style.top = '10px';
  menu.style.left = '10px';
  menu.style.background = 'white';
  menu.style.padding = '10px';
  menu.style.border = '1px solid black';
  menu.style.zIndex = '99999'; // Updated z-index value
  menu.style.cursor = 'move';
  menu.style.userSelect = 'none';
  menu.draggable = true;

  menu.appendChild(startButton);
  menu.appendChild(stopButton);

  document.body.appendChild(menu);

  function handleDrag(event) {
    const { pageX, pageY } = event;
    menu.style.top = `${pageY}px`;
    menu.style.left = `${pageX}px`;
  }

  menu.addEventListener('mousedown', () => {
    document.addEventListener('mousemove', handleDrag);
  });

  document.addEventListener('mouseup', () => {
    document.removeEventListener('mousemove', handleDrag);
  });
})();
